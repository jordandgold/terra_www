jQuery(document).ready(function($){

	$('[data-close=alert]').click(function() {
		$(this).parent().toggle();
	});

}); 